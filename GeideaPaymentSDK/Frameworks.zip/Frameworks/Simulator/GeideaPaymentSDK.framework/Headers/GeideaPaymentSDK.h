//
//  GeideaPaymentSDK.h
//  GeideaPaymentSDK
//
//  Created by euvid on 12/10/2020.
//

#import <Foundation/Foundation.h>

//! Project version number for GeideaPaymentSDK.
FOUNDATION_EXPORT double GeideaPaymentSDKVersionNumber;

//! Project version string for GeideaPaymentSDK.
FOUNDATION_EXPORT const unsigned char GeideaPaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GeideaPaymentSDK/PublicHeader.h>

